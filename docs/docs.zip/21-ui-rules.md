# UI Rules

# Tujuan

Dokumen ini menjadi standar resmi desain antarmuka Farisium.

Seluruh halaman, komponen, dan fitur baru harus mengikuti aturan ini agar pengalaman pengguna tetap konsisten di seluruh platform.

---

# Filosofi

Desain Farisium harus terasa:

* Premium.
* Modern.
* Minimalis.
* Profesional.
* Futuristik.
* Mudah digunakan.

Keindahan visual tidak boleh mengorbankan keterbacaan maupun performa.

---

# Layout

Gunakan layout yang sederhana.

Selalu gunakan:

* Container yang konsisten.
* Grid yang rapi.
* Alignment yang jelas.
* White Space yang cukup.

Jangan memenuhi layar dengan terlalu banyak elemen.

---

# Container

Gunakan satu ukuran container utama di seluruh website.

Container harus memberikan ruang yang nyaman pada desktop maupun mobile.

Hindari perubahan ukuran container yang tidak konsisten antar halaman.

---

# Spacing

Gunakan sistem spacing yang konsisten.

Seluruh margin dan padding mengikuti skala:

* 4px
* 8px
* 12px
* 16px
* 24px
* 32px
* 48px
* 64px
* 96px
* 128px

Jangan menggunakan nilai acak.

---

# Border Radius

Gunakan radius yang konsisten.

Prioritas:

* Small
* Medium
* Large

Hindari penggunaan radius yang berbeda pada komponen sejenis.

---

# Typography

Gunakan hierarki yang jelas.

Pastikan:

* Heading mudah dibedakan.
* Body nyaman dibaca.
* Line Height cukup.
* Kontras tinggi.

Hindari penggunaan terlalu banyak ukuran font.

---

# Warna

Gunakan identitas visual Farisium.

Dominasi:

* Dark Theme.
* Abu gelap.
* Putih.

Aksen:

* Ungu.
* Biru.

Gunakan warna aksen hanya untuk menarik perhatian pada elemen penting.

---

# Glassmorphism

Glassmorphism digunakan secara terbatas.

Prioritaskan pada:

* Hero.
* Dialog.
* Floating Card.
* Dashboard.

Jangan menerapkan Glassmorphism pada seluruh halaman.

---

# Shadow

Gunakan bayangan yang lembut.

Shadow bertujuan memperjelas hierarki visual, bukan menjadi elemen dekoratif.

---

# Button

Button harus:

* mudah dikenali;
* memiliki ukuran yang nyaman;
* memiliki Hover State;
* memiliki Focus State;
* memiliki Disabled State;
* memiliki Loading State.

Primary Button hanya digunakan untuk aksi utama.

---

# Form

Input harus:

* mudah dibaca;
* memiliki label yang jelas;
* memiliki validasi yang mudah dipahami;
* memberikan feedback apabila terjadi kesalahan.

---

# Card

Seluruh Card menggunakan gaya visual yang konsisten.

Card harus:

* memiliki padding yang cukup;
* memiliki radius yang sama;
* memiliki hierarki informasi yang jelas.

---

# Ikon

Gunakan ikon secara konsisten.

Ikon hanya digunakan apabila benar-benar membantu pemahaman.

Jangan menggunakan ikon sebagai dekorasi berlebihan.

---

# Animasi

Gunakan animasi yang halus.

Prioritaskan:

* Fade.
* Scale.
* Slide.
* Micro Interaction.

Durasi animasi harus singkat.

Animasi tidak boleh menghambat interaksi pengguna.

---

# Scroll

Scrolling harus terasa ringan.

Gunakan efek scroll hanya apabila meningkatkan pengalaman pengguna.

---

# Mobile First

Seluruh desain dimulai dari tampilan mobile.

Pastikan:

* tombol mudah ditekan;
* teks mudah dibaca;
* navigasi sederhana;
* layout tetap rapi.

---

# Responsive

Seluruh komponen harus bekerja dengan baik pada:

* Mobile.
* Tablet.
* Desktop.

Jangan membuat layout khusus desktop tanpa mempertimbangkan mobile.

---

# Accessibility

Seluruh UI harus:

* dapat digunakan menggunakan keyboard;
* memiliki Focus State;
* memiliki kontras yang baik;
* menggunakan Semantic HTML.

---

# SEO Friendly

Desain harus mendukung SEO.

Jangan membuat struktur halaman yang menyulitkan mesin pencari memahami isi konten.

---

# Google AdSense Friendly

Desain harus menyediakan ruang yang wajar untuk iklan.

Iklan tidak boleh:

* menutupi konten;
* mengganggu navigasi;
* mengubah layout saat dimuat.

---

# Konsistensi

Sebelum membuat komponen baru, periksa apakah komponen serupa sudah tersedia.

Gunakan kembali komponen yang ada apabila memungkinkan.

---

# Prinsip Akhir

Apabila sebuah desain terlihat menarik tetapi mengurangi kenyamanan pengguna, maka desain tersebut harus diperbaiki.

Identitas Farisium dibangun melalui konsistensi, kesederhanaan, dan kualitas pengalaman pengguna, bukan melalui efek visual yang berlebihan.
