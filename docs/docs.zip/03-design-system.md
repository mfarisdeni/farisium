# Design System

## Identitas

Premium

Modern

Dark

Elegant

Luxury

Minimal

Professional

---

## Warna

Dominan:

Hitam

Abu gelap

Putih

Aksen:

Ungu

Biru

Glass

---

## Layout

Banyak whitespace.

Grid rapi.

Container konsisten.

---

## Border Radius

16px

24px

32px

---

## Shadow

Soft

Blur

Tidak keras.

---

## Glassmorphism

Digunakan secukupnya.

Tidak semua elemen menggunakan glass.

---

## Animasi

Gunakan Framer Motion.

Durasi pendek.

Halus.

Tidak mengganggu.

---

## DNA UI

Stripe

Linear

Raycast

Vercel

Notion

Nodera (AI Compute saja)

Jangan pernah menyalin secara langsung.