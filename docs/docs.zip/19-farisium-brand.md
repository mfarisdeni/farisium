# Farisium Brand Guidelines

# Identitas Merek

Farisium adalah platform AI terpadu yang menghubungkan berbagai AI Tools, layanan digital, dan komunitas ke dalam satu ekosistem.

Farisium dibangun dengan tujuan memberikan teknologi AI yang mudah diakses, cepat, bermanfaat, dan berkelanjutan.

Farisium bukan sekadar penyedia AI Tools, tetapi sebuah ekosistem yang terus berkembang.

---

# Visi Brand

Menjadi platform AI yang membantu individu, kreator, pelaku usaha, dan developer memanfaatkan Artificial Intelligence dengan cara yang sederhana, modern, dan terpercaya.

---

# Misi Brand

* Mengembangkan AI Tools yang bermanfaat.
* Menyediakan pengalaman pengguna terbaik.
* Membangun ekosistem AI yang saling terhubung.
* Mengembangkan teknologi secara berkelanjutan.
* Memberikan nilai nyata kepada komunitas.

---

# Nilai Utama

Seluruh produk Farisium harus mencerminkan nilai berikut.

* Sederhana
* Cepat
* Modern
* Profesional
* Transparan
* Konsisten
* Berkelanjutan

---

# Karakter Brand

Farisium harus selalu terasa:

* Premium
* Futuristik
* Elegan
* Minimalis
* Bersih
* Ramah
* Profesional
* Mudah digunakan

---

# Target Pengguna

Farisium ditujukan untuk:

* Pengguna umum.
* Kreator.
* Pelaku UMKM.
* Freelancer.
* Software Developer.
* Digital Creator.
* AI Enthusiast.
* Startup.

---

# Positioning

Farisium adalah platform AI lokal dengan kualitas global.

Fokus utama bukan menjadi yang paling banyak fiturnya, tetapi menjadi platform AI yang paling nyaman digunakan.

---

# Tone of Voice

Komunikasi Farisium harus:

* Profesional.
* Ramah.
* Mudah dipahami.
* Tidak berlebihan.
* Tidak menggunakan clickbait.
* Tidak menggunakan klaim yang tidak dapat dibuktikan.

Gunakan bahasa yang sederhana namun tetap menunjukkan kualitas.

---

# Gaya Penulisan

Gunakan kalimat yang:

* Ringkas.
* Informatif.
* Jelas.
* Mudah dipahami.

Hindari istilah teknis jika tidak diperlukan.

Jika menggunakan istilah teknis, sertakan penjelasan yang mudah dipahami.

---

# Identitas Visual

Desain Farisium harus:

* Dark Theme.
* Premium.
* Modern.
* Banyak whitespace.
* Glassmorphism yang halus.
* Motion yang elegan.
* Fokus pada konten.

Animasi digunakan untuk meningkatkan pengalaman pengguna, bukan sebagai hiasan.

---

# Referensi Desain

Inspirasi yang digunakan:

* Stripe
* Linear
* Raycast
* Vercel
* Notion
* Jitter
* Ponder

Nodera hanya digunakan sebagai referensi UX pada halaman AI Compute.

Jangan pernah menyalin identitas visual website lain.

---

# Pengalaman Pengguna

Setiap halaman harus:

* Cepat dimuat.
* Mudah dipahami.
* Mobile First.
* Responsif.
* Ramah Google AdSense.
* Memiliki navigasi yang jelas.
* Mengutamakan aksesibilitas.

---

# Hubungan Antar Produk

Seluruh layanan merupakan bagian dari Farisium.

Contohnya:

* Anime Generator.
* AI Compute.
* Blog.
* Rewards.
* Partnership.

Produk-produk tersebut bukan brand terpisah.

Seluruh identitas visual harus tetap menggunakan branding Farisium.

---

# Prinsip Pengembangan Brand

Saat membuat halaman, fitur, maupun konten, selalu tanyakan:

Apakah ini terlihat seperti Farisium?

Jika sebuah desain dapat ditempel logo lain tanpa perubahan apa pun, maka desain tersebut belum memiliki identitas Farisium yang kuat.

---

# Tujuan Jangka Panjang

Farisium harus dikenal sebagai platform AI yang:

* Modern.
* Terpercaya.
* Mudah digunakan.
* Berkualitas tinggi.
* Memiliki identitas visual yang konsisten.
* Memberikan pengalaman pengguna terbaik.
