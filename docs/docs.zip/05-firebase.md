# Firebase

Backend utama.

Gunakan:

Authentication

Firestore

Storage

---

Jangan pernah mengganti backend.

Seluruh data utama menggunakan Firestore.

Selalu mempertimbangkan Security Rules.

Tidak menyimpan Secret pada client.

Gunakan Environment Variable.