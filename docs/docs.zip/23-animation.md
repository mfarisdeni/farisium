# Animation Guidelines

# Tujuan

Animasi pada Farisium digunakan untuk meningkatkan pengalaman pengguna, memperjelas interaksi, dan memberikan kesan premium.

Animasi bukan dekorasi.

Setiap animasi harus memiliki tujuan yang jelas.

---

# Filosofi

Motion merupakan bagian dari pengalaman pengguna.

Animasi harus terasa:

* Halus.
* Ringan.
* Elegan.
* Profesional.
* Cepat.
* Tidak mengganggu.

Jika sebuah animasi tidak memberikan manfaat terhadap pengalaman pengguna, maka animasi tersebut tidak digunakan.

---

# Identitas Motion Farisium

Karakter animasi Farisium adalah:

* Premium.
* Futuristik.
* Minimalis.
* Responsive.
* Natural.

Animasi harus memberikan kesan bahwa antarmuka hidup tanpa mengganggu fokus pengguna.

---

# Prinsip Utama

Gunakan animasi untuk:

* Memberikan feedback.
* Memperjelas perpindahan.
* Membantu navigasi.
* Menunjukkan perubahan state.
* Menarik perhatian pada elemen penting.

Jangan menggunakan animasi hanya karena terlihat menarik.

---

# Referensi Motion

Inspirasi motion berasal dari:

* Stripe
* Linear
* Raycast
* Jitter
* Ponder

Referensi digunakan untuk memahami kualitas pengalaman pengguna, bukan untuk menyalin implementasi.

---

# Framework

Gunakan Framer Motion sebagai library utama apabila diperlukan.

Hindari penggunaan beberapa library animasi dalam satu proyek.

---

# Durasi

Animasi harus singkat.

Panduan umum:

* Sangat cepat: 100–150 ms
* Cepat: 150–250 ms
* Normal: 250–350 ms
* Kompleks: maksimal 500 ms

Hindari animasi dengan durasi terlalu lama.

---

# Easing

Gunakan easing yang terasa natural.

Prioritaskan:

* Ease Out
* Ease In Out
* Spring ringan

Hindari easing yang membuat gerakan terasa kaku atau berlebihan.

---

# Hover

Hover harus memberikan feedback yang jelas.

Efek yang diperbolehkan:

* Perubahan warna.
* Perubahan opacity.
* Scale kecil.
* Shadow halus.
* Glass blur ringan.

Hover tidak boleh mengubah layout.

---

# Button

Button dapat memiliki:

* Hover.
* Active.
* Focus.
* Loading.

Hover harus terasa responsif.

Loading harus memberikan indikasi proses yang sedang berlangsung.

---

# Card

Card dapat menggunakan:

* Hover Elevation.
* Scale ringan.
* Shadow lembut.
* Border Highlight.

Card tidak boleh bergerak terlalu jauh saat hover.

---

# Navigation

Navigasi harus memiliki transisi yang halus.

Gunakan animasi saat:

* membuka menu;
* berpindah halaman;
* mengubah state navigasi.

---

# Modal

Modal harus:

* Fade In.
* Scale In ringan.
* Background Blur.

Saat ditutup:

* Fade Out.
* Scale Out ringan.

---

# Drawer

Drawer harus:

* Slide secara natural.
* Tidak muncul secara tiba-tiba.
* Memiliki overlay yang lembut.

---

# Tooltip

Tooltip muncul dengan:

* Fade.
* Slide kecil.

Tooltip harus cepat muncul dan cepat menghilang.

---

# Loading

Loading harus memberikan kepastian kepada pengguna.

Gunakan:

* Skeleton.
* Progress Bar.
* Progress Circle.

Spinner hanya digunakan apabila tidak memungkinkan menggunakan Skeleton.

---

# Progress

Progress harus memperlihatkan perkembangan proses secara jelas.

Contoh:

* Generate AI.
* Upload.
* Download.
* Processing.

---

# AI Generation

Proses AI harus memberikan feedback visual.

Status yang perlu ditampilkan:

* Waiting.
* Preparing.
* Generating.
* Finishing.
* Completed.
* Failed.

Pengguna tidak boleh merasa aplikasi berhenti bekerja.

---

# Hero Section

Hero dapat menggunakan motion ringan.

Contoh:

* Fade.
* Floating.
* Blur.
* Gradient Movement yang sangat halus.

Hero bukan tempat untuk animasi yang berlebihan.

---

# Scroll Animation

Gunakan Scroll Animation hanya apabila membantu storytelling.

Contoh:

* Fade Up.
* Fade In.
* Reveal.
* Scale ringan.

Hindari efek yang mengganggu proses membaca.

---

# Background Animation

Background boleh memiliki animasi ringan.

Contoh:

* Floating Glow.
* Noise.
* Gradient Shift.
* Particle yang sangat halus.

Background tidak boleh mengalihkan perhatian dari konten utama.

---

# Glassmorphism

Glassmorphism dapat dipadukan dengan animasi.

Gunakan:

* Blur Transition.
* Opacity.
* Highlight.

Hindari perubahan blur yang ekstrem.

---

# Responsive Animation

Animasi harus tetap nyaman pada:

* Mobile.
* Tablet.
* Desktop.

Kurangi animasi yang berat pada perangkat dengan kemampuan terbatas.

---

# Accessibility

Hormati preferensi pengguna.

Apabila sistem mendukung pengurangan animasi, gunakan versi animasi yang lebih sederhana.

Pengguna tetap harus dapat menggunakan seluruh fitur tanpa bergantung pada animasi.

---

# Performance

Animasi tidak boleh menurunkan performa.

Hindari:

* animasi yang memicu layout berulang;
* animasi yang menggunakan resource GPU secara berlebihan;
* animasi yang memperlambat interaksi.

Selalu prioritaskan pengalaman pengguna.

---

# Konsistensi

Seluruh halaman harus menggunakan gaya animasi yang sama.

Jangan mencampurkan berbagai gaya motion yang berbeda dalam satu produk.

---

# Checklist Sebelum Menambahkan Animasi

Sebelum membuat animasi, pastikan:

* Memiliki tujuan yang jelas.
* Tidak mengganggu pengguna.
* Tidak memperlambat halaman.
* Konsisten dengan Design System.
* Responsive.
* Accessibility tetap terjaga.

---

# Prinsip Akhir

Motion adalah bagian dari identitas Farisium.

Animasi yang baik tidak menarik perhatian karena berlebihan, tetapi membuat seluruh pengalaman terasa lebih halus, lebih cepat, dan lebih profesional.

Jika pengguna hampir tidak menyadari keberadaan animasi namun merasa aplikasi sangat nyaman digunakan, maka tujuan motion Farisium telah tercapai.
