# Architectural & Business Decisions

Dokumen ini merupakan sumber keputusan resmi proyek Farisium.

Seluruh AI Agent, Developer, dan kontributor harus mengikuti keputusan pada dokumen ini.

Apabila terdapat keputusan baru yang mengubah arsitektur atau arah proyek, dokumen ini wajib diperbarui.

---

# 2026-06-26

## Farisium adalah satu platform

### Keputusan

Seluruh produk dikembangkan sebagai bagian dari satu platform Farisium.

### Implementasi

Homepage berada pada:

/

Seluruh AI Tools berada pada:

/ai/*

Anime Generator:

/ai/anime-generator

### Alasan

Mempermudah pengembangan.

Meningkatkan konsistensi.

Mengurangi duplikasi kode.

Memperkuat branding.

---

# 2026-06-26

## Backend menggunakan Firebase

### Keputusan

Firebase menjadi backend utama.

### Layanan yang digunakan

* Authentication
* Firestore
* Storage
* Functions (jika diperlukan)

### Alasan

* Serverless.
* Cepat dikembangkan.
* Realtime.
* Skalabel.
* Cocok untuk Farisium.

Backend tidak diganti kecuali terdapat keputusan baru.

---

# 2026-06-26

## Deployment

### Keputusan

Deployment menggunakan Cpanel Rumahweb Node.js.

### Workflow

* Build lokal.
* Upload manual melalui File Manager.
* Tidak menggunakan GitHub Deployment.
* Tidak menggunakan Vercel Deployment.

### Alasan

Sesuai dengan workflow pengembangan Farisium.

---

# 2026-06-26

## AI Lokal

### Keputusan

Seluruh AI Development dilakukan menggunakan AI lokal.

### Teknologi

* Ollama
* Open WebUI
* Continue
* Qwen2.5-Coder
* Qwen3

### Alasan

* Privasi.
* Tidak bergantung API eksternal.
* Biaya operasional lebih rendah.
* Dapat dikembangkan secara mandiri.

---

# 2026-06-26

## FRSC

### Keputusan

FRSC digunakan sebagai utility point resmi.

### Alasan

Menghubungkan seluruh layanan Farisium ke dalam satu ekosistem.

FRSC bukan cryptocurrency maupun instrumen investasi.

---

# 2026-06-26

## Partnership

### Keputusan

Program Partnership menggunakan konsep Win-Win Contribution.

### Prinsip

* Bukan investasi.
* Tidak ada pengembalian modal.
* Tidak menjanjikan keuntungan finansial.

### Alasan

Membangun hubungan jangka panjang yang sehat antara Farisium dan komunitas.

---

# 2026-06-27

## Identitas Visual

### Keputusan

Farisium memiliki identitas visual sendiri.

### Referensi

* Stripe
* Linear
* Raycast
* Vercel
* Notion
* Jitter
* Ponder

Nodera hanya menjadi referensi UX pada halaman AI Compute.

### Alasan

Membangun identitas brand yang kuat tanpa meniru produk lain.

---

# 2026-06-27

## UI & UX

### Keputusan

Seluruh halaman harus:

* Premium.
* Dark.
* Modern.
* Minimalis.
* Mobile First.
* Ramah Google AdSense.

### Alasan

Memberikan pengalaman pengguna terbaik sekaligus mendukung pertumbuhan trafik organik.

---

# 2026-06-28

## AI Workstation

### Keputusan

Farisium menggunakan workstation AI lokal sebagai pusat pengembangan.

### Konfigurasi

* Windows + WSL2
* Docker
* Ollama
* Open WebUI
* Continue
* NVIDIA RTX 3070

### Alasan

Memungkinkan pengembangan AI secara mandiri tanpa bergantung pada layanan cloud.

---

# Aturan Perubahan

Setiap keputusan baru harus:

* Memiliki tanggal.
* Menjelaskan keputusan yang diambil.
* Menjelaskan alasan keputusan tersebut.
* Menjelaskan dampak terhadap arsitektur atau bisnis.

Dokumen ini menjadi referensi utama sebelum mengubah teknologi, struktur proyek, maupun arah pengembangan Farisium.
