# UI Components Standard

# Tujuan

Dokumen ini menjadi standar resmi seluruh komponen antarmuka pada Farisium.

Seluruh halaman harus dibangun menggunakan komponen yang dapat digunakan kembali (Reusable Components).

Jangan membuat komponen baru apabila fungsi yang sama sudah tersedia.

---

# Filosofi

Komponen harus:

* Reusable
* Modular
* Konsisten
* Mudah dipelihara
* Mudah dikembangkan

Seluruh komponen harus mengikuti Design System Farisium.

---

# Struktur Folder

Seluruh komponen UI berada pada:

```text
/components/ui
```

Komponen yang bersifat khusus dapat berada pada:

```text
/components/features
```

Komponen layout berada pada:

```text
/components/layout
```

Jangan mencampurkan komponen umum dengan komponen yang hanya digunakan oleh satu fitur.

---

# Aturan Umum

Setiap komponen harus:

* memiliki satu tanggung jawab;
* menggunakan TypeScript;
* memiliki props yang jelas;
* mudah digunakan kembali;
* mendukung responsive layout;
* mendukung Dark Theme.

---

# Layout Components

Komponen layout yang digunakan di seluruh Farisium.

* Container
* Section
* Page
* Grid
* Stack
* Divider
* Spacer

Seluruh halaman menggunakan struktur layout yang sama.

---

# Navigation Components

Komponen navigasi.

* Navbar
* Sidebar
* Mobile Menu
* Breadcrumb
* Pagination
* Tabs

Navigasi harus konsisten pada seluruh halaman.

---

# Hero Components

Hero Section terdiri dari:

* Badge
* Heading
* Description
* Primary Button
* Secondary Button
* Hero Illustration

Hero harus menjadi titik fokus halaman.

---

# Card Components

Gunakan Card sebagai komponen utama.

Jenis Card:

* Feature Card
* AI Tool Card
* Reward Card
* Pricing Card
* Partner Card
* Blog Card
* Statistic Card
* Dashboard Card

Semua Card menggunakan identitas visual Farisium.

---

# Button Components

Gunakan Button yang konsisten.

Jenis:

* Primary
* Secondary
* Outline
* Ghost
* Icon Button
* Link Button

Button harus memiliki:

* Loading State
* Disabled State
* Hover State
* Focus State

---

# Form Components

Komponen form meliputi:

* Input
* Textarea
* Select
* Checkbox
* Radio
* Switch
* Slider
* Search Box

Semua Form mengikuti Design System Farisium.

---

# Feedback Components

Komponen untuk memberikan umpan balik.

* Alert
* Toast
* Modal
* Dialog
* Drawer
* Tooltip
* Popover

Seluruh feedback harus sederhana dan mudah dipahami.

---

# Loading Components

Gunakan Loading State yang konsisten.

Komponen:

* Skeleton
* Spinner
* Progress Bar
* Progress Circle

Gunakan Skeleton sebagai pilihan utama dibanding Spinner apabila memungkinkan.

---

# Data Components

Komponen untuk menampilkan data.

* Table
* List
* Timeline
* Accordion
* FAQ
* Empty State

Data harus mudah dibaca pada desktop maupun mobile.

---

# Dashboard Components

Komponen Dashboard:

* Statistic Card
* Activity Card
* Balance Card
* Transaction Card
* Usage Card
* History Card

Dashboard harus sederhana dan fokus pada informasi penting.

---

# AI Components

Komponen khusus AI.

* Prompt Input
* Prompt Enhancement
* Negative Prompt
* Generation Settings
* Generate Button
* Progress
* Queue Status
* Image Gallery
* History
* Image Preview

Komponen ini digunakan pada seluruh AI Tools apabila relevan.

---

# Reward Components

Komponen Reward:

* Reward Card
* Reward Detail
* Claim Button
* Requirement Badge
* FRSC Badge

Menggunakan tampilan premium dan mudah dipahami.

---

# Partnership Components

Komponen Partnership:

* Benefit Card
* Contribution Card
* FAQ
* CTA Section

Menggunakan bahasa yang profesional dan transparan.

---

# Blog Components

Komponen Blog:

* Article Card
* Category Badge
* Reading Time
* Author
* Related Article

Artikel harus nyaman dibaca.

---

# Footer Components

Footer minimal terdiri dari:

* Logo
* Deskripsi singkat
* Navigasi
* Social Media
* Copyright

Footer digunakan pada seluruh halaman publik.

---

# Animation

Animasi digunakan untuk meningkatkan pengalaman pengguna.

Gunakan:

* Fade
* Scale
* Slide
* Hover
* Micro Interaction

Hindari animasi yang berlebihan.

---

# Glassmorphism

Glassmorphism digunakan secara terbatas.

Prioritaskan pada:

* Hero
* Dashboard
* Dialog
* Floating Card

Jangan menerapkan Glassmorphism pada seluruh halaman.

---

# Responsive

Seluruh komponen harus:

* Mobile First
* Tablet Friendly
* Desktop Friendly

Komponen tidak boleh memiliki ukuran tetap yang menyebabkan layout rusak pada perangkat kecil.

---

# Accessibility

Seluruh komponen harus:

* mendukung keyboard navigation;
* memiliki focus state;
* menggunakan semantic HTML;
* memiliki label yang jelas;
* memenuhi standar kontras warna.

---

# Reusability

Sebelum membuat komponen baru, AI harus:

1. mencari komponen yang sudah ada;
2. mengevaluasi apakah dapat digunakan kembali;
3. memperluas komponen yang ada apabila memungkinkan.

Duplikasi komponen harus dihindari.

---

# Naming Convention

Nama komponen harus:

* jelas;
* konsisten;
* menggunakan PascalCase.

Contoh:

* HeroSection
* FeatureCard
* RewardCard
* GenerateButton
* PromptInput

Hindari nama yang terlalu umum atau tidak menggambarkan fungsinya.

---

# Checklist Sebelum Membuat Komponen Baru

Sebelum membuat komponen baru, pastikan:

* Belum ada komponen dengan fungsi yang sama.
* Mengikuti Design System Farisium.
* Responsive.
* Mendukung Dark Theme.
* Reusable.
* Mudah dipelihara.
* Tidak menambah kompleksitas yang tidak diperlukan.

---

# Prinsip Akhir

Komponen adalah fondasi antarmuka Farisium.

Setiap komponen harus dirancang agar dapat digunakan pada banyak halaman, menjaga konsistensi visual, mengurangi duplikasi kode, dan mempercepat proses pengembangan.

Jika sebuah komponen hanya digunakan satu kali, evaluasi kembali apakah komponen tersebut benar-benar perlu dipisahkan atau cukup menjadi bagian dari halaman yang menggunakannya.
