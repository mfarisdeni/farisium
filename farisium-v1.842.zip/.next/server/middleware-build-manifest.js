globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/vyZWnr8gDQ_3bhx3iQkOL/_buildManifest.js",
    "static/vyZWnr8gDQ_3bhx3iQkOL/_ssgManifest.js",
    "static/vyZWnr8gDQ_3bhx3iQkOL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/08kw1lts~~ut5.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0imr3j_iy8.ac.js",
    "static/chunks/0m_p1bxtorv5i.js",
    "static/chunks/turbopack-0bymwok27a3m-.js"
  ]
};
