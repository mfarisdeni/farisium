globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/f5x4FJq-yDrtglNU8IAt8/_buildManifest.js",
    "static/f5x4FJq-yDrtglNU8IAt8/_ssgManifest.js",
    "static/f5x4FJq-yDrtglNU8IAt8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/08kw1lts~~ut5.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0imr3j_iy8.ac.js",
    "static/chunks/0m_p1bxtorv5i.js",
    "static/chunks/turbopack-0bymwok27a3m-.js"
  ]
};
