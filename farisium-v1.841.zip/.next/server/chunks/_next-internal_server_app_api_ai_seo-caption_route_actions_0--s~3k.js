module.exports=[35593,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_seo-caption_route_actions_0--s~3k.js.map