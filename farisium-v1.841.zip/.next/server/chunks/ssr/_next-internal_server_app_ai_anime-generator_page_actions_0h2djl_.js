module.exports=[56009,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ai_anime-generator_page_actions_0h2djl_.js.map