module.exports=[57774,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_frsc-audit-trail-x7k9m2n4_page_actions_130bhb-.js.map