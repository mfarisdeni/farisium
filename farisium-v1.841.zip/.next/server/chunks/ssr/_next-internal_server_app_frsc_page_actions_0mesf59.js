module.exports=[75687,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_frsc_page_actions_0mesf59.js.map