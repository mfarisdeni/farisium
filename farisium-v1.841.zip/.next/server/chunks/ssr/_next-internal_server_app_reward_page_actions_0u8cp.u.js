module.exports=[28476,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reward_page_actions_0u8cp.u.js.map