module.exports=[34611,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_author_faris_page_actions_0d.jysx.js.map