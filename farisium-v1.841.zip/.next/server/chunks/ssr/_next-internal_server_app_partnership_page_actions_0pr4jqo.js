module.exports=[2142,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partnership_page_actions_0pr4jqo.js.map