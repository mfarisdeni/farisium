module.exports=[2349,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ai_seo-caption-generator_page_actions_108tu1u.js.map