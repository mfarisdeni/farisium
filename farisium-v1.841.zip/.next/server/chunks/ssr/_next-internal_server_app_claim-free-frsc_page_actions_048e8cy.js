module.exports=[42367,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_claim-free-frsc_page_actions_048e8cy.js.map