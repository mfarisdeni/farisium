module.exports=[42101,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_frsc-transactions_route_actions_0aug~v5.js.map