var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/fium/chat/route.js")
R.c("server/chunks/[root-of-the-server]__0kg5_yr._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_fium_chat_route_actions_0k4bqaw.js")
R.m(41899)
module.exports=R.m(41899).exports
