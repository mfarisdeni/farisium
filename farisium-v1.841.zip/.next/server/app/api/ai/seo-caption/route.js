var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/seo-caption/route.js")
R.c("server/chunks/[root-of-the-server]__0_yobrx._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_seo-caption_route_actions_0--s~3k.js")
R.m(10292)
module.exports=R.m(10292).exports
