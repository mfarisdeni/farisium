var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0mk9dqb._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/_0gtaf0~._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_0zukc38.js")
R.m(74378)
module.exports=R.m(74378).exports
