var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/f-stream-spotify-promotion/order/route.js")
R.c("server/chunks/[root-of-the-server]__097iz47._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0hl_w~.._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/0zjb_server_app_api_f-stream-spotify-promotion_order_route_actions_0r.ybiu.js")
R.m(98164)
module.exports=R.m(98164).exports
