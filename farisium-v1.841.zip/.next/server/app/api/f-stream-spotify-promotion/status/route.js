var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/f-stream-spotify-promotion/status/route.js")
R.c("server/chunks/[root-of-the-server]__0n.20h2._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0hl_w~.._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/0zjb_server_app_api_f-stream-spotify-promotion_status_route_actions_02_q~d5.js")
R.m(61556)
module.exports=R.m(61556).exports
