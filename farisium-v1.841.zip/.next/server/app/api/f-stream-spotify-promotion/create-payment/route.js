var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/f-stream-spotify-promotion/create-payment/route.js")
R.c("server/chunks/[root-of-the-server]__0tev9za._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/0zjb_server_app_api_f-stream-spotify-promotion_create-payment_route_actions_0sqzqsp.js")
R.m(45259)
module.exports=R.m(45259).exports
