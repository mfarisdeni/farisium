var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/web-builder/order/route.js")
R.c("server/chunks/[root-of-the-server]__020bnzo._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0hl_w~.._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/_next-internal_server_app_api_web-builder_order_route_actions_0k1sdef.js")
R.m(16766)
module.exports=R.m(16766).exports
