var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/frsc-transactions/route.js")
R.c("server/chunks/[root-of-the-server]__0gscu7d._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_frsc-transactions_route_actions_0aug~v5.js")
R.m(32004)
module.exports=R.m(32004).exports
