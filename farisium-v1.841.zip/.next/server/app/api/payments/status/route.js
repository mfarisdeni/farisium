var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/status/route.js")
R.c("server/chunks/[root-of-the-server]__0wx5qcu._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_status_route_actions_0_ewsyk.js")
R.m(90420)
module.exports=R.m(90420).exports
