var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/log/route.js")
R.c("server/chunks/[root-of-the-server]__0hbvn4i._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_log_route_actions_0.dsv2l.js")
R.m(44305)
module.exports=R.m(44305).exports
