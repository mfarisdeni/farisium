var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0g-mpl_._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_webhook_route_actions_0yb-eny.js")
R.m(98924)
module.exports=R.m(98924).exports
