var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/create/route.js")
R.c("server/chunks/[root-of-the-server]__0e~oae7._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_create_route_actions_11yofgz.js")
R.m(458)
module.exports=R.m(458).exports
