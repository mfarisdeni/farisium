var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0h-elw3._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/lib_blog_ts_12ca9_4._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(8922)
module.exports=R.m(8922).exports
