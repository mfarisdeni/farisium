var R=require("../../chunks/[turbopack]_runtime.js")("server/app/rss.xml/route.js")
R.c("server/chunks/[root-of-the-server]__11ai3~o._.js")
R.c("server/chunks/lib_blog_ts_12ca9_4._.js")
R.c("server/chunks/[root-of-the-server]__0locdyx._.js")
R.c("server/chunks/_next-internal_server_app_rss_xml_route_actions_0lr5us~.js")
R.m(65324)
module.exports=R.m(65324).exports
